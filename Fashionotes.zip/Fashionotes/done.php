<?php include 'header.php'; ?>
<title>Homepage | Trishul</title>
<?php include 'navbar.php' ?>

<?php

    echo "<h1>Thank you this will be very helpful</h1>";
?>
<a href="index.php">Click here to redirect</a>
<?php include 'footer.php'; ?>
</body>
</html>
